<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/', 'Home::index', ['filter' => 'faq']);

// $routes->get('login', 'AuthController::login');
// $routes->post('login', 'AuthController::login');
// $routes->get('logout', 'AuthController::logout');

$routes->get('login', 'FaqRedirectController::login');
$routes->post('login', 'FaqRedirectController::login');
$routes->get('logout', 'FaqRedirectController::logout');

$routes->get('produk', 'ProdukController::index', ['filter' => 'faq']);
$routes->get('keranjang', 'TransaksiController::index', ['filter' => 'faq']);
$routes->get('faq', 'FaqController::index');


