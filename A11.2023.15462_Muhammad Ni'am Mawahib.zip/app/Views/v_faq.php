<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
Ini halaman Faq
<?= $this->endSection() ?>
