<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(): string
    {
        return view('v_home');
    }

    public function contact()
    {
        return view('template/header')
            . view('contact')
            . view('template/footer');
    }

    public function Faq()
    {
        return view('template/header')
            . view('Faq')
            . view('template/footer');
    }
}

